{
    "name": "Academic Dashboard",
    "version": "16.0.1.0",
    "category": "Tools",
    "author": "ChatGPT",
    "summary": "Dashboard with statistics for the academic module",
    "depends": ["base"],
    "data": [
        "views/dashboard_views.xml"
    ],
    "assets": {
        "web.assets_backend": [
            "dashboard_academic/static/src/xml/dashboard_academic.xml"
        ]
    },
    "installable": True,
    "application": True,
    "license": "LGPL-3"
}