{
    "name": "Dashboard Académico",
    "version": "1.0",
    "summary": "Dashboard con estadísticas académicas",
    "author": "ChatGPT",
    "depends": ["base", "web"],
    "data": [
        "security/ir.model.access.csv",
        "views/dashboard_views.xml"
    ],
    "assets": {
        "web.assets_backend": [
            "dashboard_academic/static/src/js/dashboard_academic.js",
            "dashboard_academic/static/src/xml/dashboard_academic.xml"
        ]
    },
    "installable": True,
    "application": True
}