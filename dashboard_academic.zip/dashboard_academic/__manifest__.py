{
    "name": "Dashboard Académico",
    "version": "16.0.1.0",
    "category": "Education",
    "summary": "Academic Dashboard with statistics",
    "author": "ChatGPT",
    "depends": ["base"],
    "data": [
        "views/dashboard_view.xml"
    ],
    "installable": True,
    "application": True,
    "license": "LGPL-3"
}