from odoo import http
from odoo.http import request

class DashboardAcademic(http.Controller):
    @http.route('/dashboard_academic', type='http', auth='user', website=True)
    def dashboard_academic(self, **kw):
        return request.render('dashboard_academic.dashboard_template', {})