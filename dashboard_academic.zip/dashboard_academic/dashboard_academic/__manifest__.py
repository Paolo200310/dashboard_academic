{
    "name": "Dashboard Academic",
    "version": "1.0",
    "summary": "Academic dashboard with student and grade stats",
    "depends": ["base", "web"],
    "data": [
        "views/dashboard_template.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "dashboard_academic/static/src/js/dashboard_component.js",
        ]
    },
    "installable": True,
    "application": True,
}