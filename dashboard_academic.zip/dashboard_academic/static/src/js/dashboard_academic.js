odoo.define('dashboard_academic.dashboard', function (require) {
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');

    var Dashboard = AbstractAction.extend({
        template: 'DashboardTemplate',
        start: function () {
            this.$el.append('<h2>Panel de Estadísticas Académicas</h2>');
            this.$el.append('<p>Este dashboard puede ser mejorado con KPIs, gráficos y más.</p>');
        }
    });

    core.action_registry.add('dashboard_academic_client', Dashboard);
    return Dashboard;
});