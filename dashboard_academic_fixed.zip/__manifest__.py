
{
    'name': 'Academic Dashboard',
    'version': '1.0',
    'summary': 'Manage students, grades, and attendances',
    'category': 'Education',
    'depends': ['base'],
    'data': [
        'views/dashboard_view.xml',
    ],
    'installable': True,
    'application': True,
}
