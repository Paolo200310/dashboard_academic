/** @odoo-module **/

import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

export class DashboardAcademic extends Component {
    setup() {
        this.students = [];
        this.subjects = [];
    }
}

DashboardAcademic.template = "dashboard_academic.DashboardTemplate";

registry.category("actions").add("dashboard_academic", DashboardAcademic);
