/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component } from "@odoo/owl";

export class DashboardAcademic extends Component {}

DashboardAcademic.template = "dashboard_academic.DashboardTemplate";

registry.category("actions").add("dashboard_academic", DashboardAcademic);
