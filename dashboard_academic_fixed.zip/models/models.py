
from odoo import models, fields

class Student(models.Model):
    _name = 'academic.student'
    _description = 'Student'

    name = fields.Char(required=True)
    semester = fields.Integer(string="Semester")
    grades_ids = fields.One2many('academic.grade', 'student_id', string="Grades")
    attendances_ids = fields.One2many('academic.attendance', 'student_id', string="Attendances")

class Grade(models.Model):
    _name = 'academic.grade'
    _description = 'Grade'

    student_id = fields.Many2one('academic.student', string="Student")
    subject = fields.Char(required=True)
    score = fields.Float(required=True)

class Attendance(models.Model):
    _name = 'academic.attendance'
    _description = 'Attendance'

    student_id = fields.Many2one('academic.student', string="Student")
    date = fields.Date(required=True)
    status = fields.Selection([('present', 'Present'), ('absent', 'Absent')], required=True)
