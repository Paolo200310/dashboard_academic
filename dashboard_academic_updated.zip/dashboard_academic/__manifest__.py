{
    "name": "Dashboard Academic",
    "version": "16.0.1.0.0",
    "category": "Tools",
    "summary": "Academic dashboard",
    "author": "ChatGPT",
    "depends": ["base"],
    "data": ["views/dashboard_views.xml"],
    "assets": {
        "web.assets_backend": [
            "dashboard_academic/static/src/js/dashboard_academic.js",
            "dashboard_academic/static/src/xml/dashboard_academic.xml"
        ]
    },
    "installable": True,
    "application": True,
    "license": "LGPL-3"
}
