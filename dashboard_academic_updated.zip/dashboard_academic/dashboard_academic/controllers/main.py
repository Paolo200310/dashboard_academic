from odoo import http
from odoo.http import request

class DashboardAcademic(http.Controller):
    @http.route('/dashboard/academic', auth='user', type='http', website=False)
    def dashboard_academic(self, **kwargs):
        students = request.env['academic.student'].sudo().search([])
        subjects = request.env['academic.subject'].sudo().search([])
        grades = request.env['academic.grade'].sudo().search([])

        return request.render('dashboard_academic.dashboard_template', {
            'students': students,
            'subjects': subjects,
            'grades': grades,
        })